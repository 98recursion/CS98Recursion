The combined js file is created at

http://codemirror.net/doc/compress.html

Selecting javascript, simple-hint and javascript-hint, and adding the
SoleMirror.js to the Custom code field.